# Vanguard Arena — Android APK Project

Developed by **VictorTheGreat** & **Williamson22**.

## Option A: Build a Signed or Debug `.apk` in Android Studio
1. Open the `VanguardArena-Android` folder in **Android Studio** (Hedgehog / Koala / Ladybug or newer).
2. Let Gradle sync automatically.
3. Click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Copy `app/build/outputs/apk/debug/app-debug.apk` to your Android phone and tap it to install!

## Option B: Instant Zero-Build Install on Android Chrome
1. Open `https://ais-pre-noyxaeeepimqzdkajl5ohh-968396106300.asia-east1.run.app` in Google Chrome on Android.
2. Tap the **Install App** button inside the Vanguard Arena lobby (or Chrome menu **⋮ > Add to Home screen / Install app**).
